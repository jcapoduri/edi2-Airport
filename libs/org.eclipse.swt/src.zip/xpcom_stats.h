/* ***** BEGIN LICENSE BLOCK *****
* Version: MPL 1.1
*
* The contents of this file are subject to the Mozilla Public License Version
* 1.1 (the "License"); you may not use this file except in compliance with
* the License. You may obtain a copy of the License at
* http://www.mozilla.org/MPL/
*
* Software distributed under the License is distributed on an "AS IS" basis,
* WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
* for the specific language governing rights and limitations under the
* License.
*
* The Original Code is Mozilla Communicator client code, released March 31, 1998.
*
* The Initial Developer of the Original Code is
* Netscape Communications Corporation.
* Portions created by Netscape are Copyright (C) 1998-1999
* Netscape Communications Corporation.  All Rights Reserved.
*
* Contributor(s):
*
* IBM
* -  Binding to permit interfacing between Mozilla and SWT
* -  Copyright (C) 2003, 2004 IBM Corp.  All Rights Reserved.
*
* ***** END LICENSE BLOCK ***** */

#ifdef NATIVE_STATS
extern int XPCOM_nativeFunctionCount;
extern int XPCOM_nativeFunctionCallCount[];
extern char* XPCOM_nativeFunctionNames[];
#define XPCOM_NATIVE_ENTER(env, that, func) XPCOM_nativeFunctionCallCount[func]++;
#define XPCOM_NATIVE_EXIT(env, that, func) 
#else
#define XPCOM_NATIVE_ENTER(env, that, func) 
#define XPCOM_NATIVE_EXIT(env, that, func) 
#endif

typedef enum {
	Call_FUNC,
	NS_1GetComponentManager_FUNC,
	NS_1GetServiceManager_FUNC,
	NS_1InitEmbedding_FUNC,
	NS_1NewLocalFile_FUNC,
	NS_1TermEmbedding_FUNC,
	PR_1Free_FUNC,
	PR_1Malloc_FUNC,
	VtblCall__IJ_FUNC,
	VtblCall__IJF_FUNC,
	VtblCall__IJI_FUNC,
	VtblCall__IJIIIII_FUNC,
	VtblCall__IJIIIIZ_FUNC,
	VtblCall__IJIIZ_FUNC,
	VtblCall__IJII_3C_FUNC,
	VtblCall__IJII_3J_FUNC,
	VtblCall__IJIJJ_FUNC,
	VtblCall__IJI_3B_3Z_FUNC,
	VtblCall__IJI_3C_FUNC,
	VtblCall__IJI_3I_3I_3I_3I_FUNC,
	VtblCall__IJJ_FUNC,
	VtblCall__IJJI_FUNC,
	VtblCall__IJJI_3J_FUNC,
	VtblCall__IJJJ_FUNC,
	VtblCall__IJJJI_FUNC,
	VtblCall__IJJJII_FUNC,
	VtblCall__IJJJIIII_FUNC,
	VtblCall__IJJJIZ_FUNC,
	VtblCall__IJJJI_3C_FUNC,
	VtblCall__IJJJI_3I_FUNC,
	VtblCall__IJJJJ_FUNC,
	VtblCall__IJJJJJJ_FUNC,
	VtblCall__IJJJJZ_3CJJIJZ_3J_3J_FUNC,
	VtblCall__IJJJ_3CJJJ_FUNC,
	VtblCall__IJJLorg_eclipse_swt_internal_mozilla_nsID_2_FUNC,
	VtblCall__IJJLorg_eclipse_swt_internal_mozilla_nsID_2_3J_FUNC,
	VtblCall__IJJZ_FUNC,
	VtblCall__IJJZZ_FUNC,
	VtblCall__IJJZZJI_FUNC,
	VtblCall__IJJZZJIIIIIZZZZSJ_FUNC,
	VtblCall__IJJZ_3Z_FUNC,
	VtblCall__IJJ_3BJ_3J_FUNC,
	VtblCall__IJJ_3B_3B_3BJ_3J_FUNC,
	VtblCall__IJJ_3CI_FUNC,
	VtblCall__IJJ_3C_3C_FUNC,
	VtblCall__IJJ_3C_3CI_3C_3C_3C_3C_3Z_3I_FUNC,
	VtblCall__IJJ_3C_3CI_3J_3I_3Z_FUNC,
	VtblCall__IJJ_3C_3C_3C_3Z_FUNC,
	VtblCall__IJJ_3C_3C_3C_3Z_3Z_FUNC,
	VtblCall__IJJ_3C_3C_3J_FUNC,
	VtblCall__IJJ_3C_3C_3J_3C_3Z_3Z_FUNC,
	VtblCall__IJJ_3C_3C_3J_3J_3C_3Z_3Z_FUNC,
	VtblCall__IJJ_3C_3C_3Z_FUNC,
	VtblCall__IJJ_3J_FUNC,
	VtblCall__IJJ_3Z_FUNC,
	VtblCall__IJLorg_eclipse_swt_internal_mozilla_nsID_2J_FUNC,
	VtblCall__IJLorg_eclipse_swt_internal_mozilla_nsID_2JLorg_eclipse_swt_internal_mozilla_nsID_2_3J_FUNC,
	VtblCall__IJLorg_eclipse_swt_internal_mozilla_nsID_2Lorg_eclipse_swt_internal_mozilla_nsID_2_3J_FUNC,
	VtblCall__IJLorg_eclipse_swt_internal_mozilla_nsID_2Lorg_eclipse_swt_internal_mozilla_nsID_2_3Z_FUNC,
	VtblCall__IJLorg_eclipse_swt_internal_mozilla_nsID_2_3B_3BJ_FUNC,
	VtblCall__IJLorg_eclipse_swt_internal_mozilla_nsID_2_3B_3BJ_3B_3B_FUNC,
	VtblCall__IJLorg_eclipse_swt_internal_mozilla_nsID_2_3J_FUNC,
	VtblCall__IJLorg_eclipse_swt_internal_mozilla_nsID_2_3Z_FUNC,
	VtblCall__IJZ_FUNC,
	VtblCall__IJZJ_FUNC,
	VtblCall__IJZ_3Z_FUNC,
	VtblCall__IJ_3BI_FUNC,
	VtblCall__IJ_3BI_3I_FUNC,
	VtblCall__IJ_3BJ_FUNC,
	VtblCall__IJ_3BJLorg_eclipse_swt_internal_mozilla_nsID_2_3J_FUNC,
	VtblCall__IJ_3BLorg_eclipse_swt_internal_mozilla_nsID_2_3J_FUNC,
	VtblCall__IJ_3BLorg_eclipse_swt_internal_mozilla_nsID_2_3Z_FUNC,
	VtblCall__IJ_3BZJ_3J_3Z_FUNC,
	VtblCall__IJ_3BZ_3J_3Z_FUNC,
	VtblCall__IJ_3B_3I_FUNC,
	VtblCall__IJ_3B_3J_FUNC,
	VtblCall__IJ_3B_3J_3Z_FUNC,
	VtblCall__IJ_3B_3Z_FUNC,
	VtblCall__IJ_3C_FUNC,
	VtblCall__IJ_3CIJJJ_FUNC,
	VtblCall__IJ_3CJ_3J_FUNC,
	VtblCall__IJ_3CZ_FUNC,
	VtblCall__IJ_3C_3C_FUNC,
	VtblCall__IJ_3C_3C_3CZ_FUNC,
	VtblCall__IJ_3C_3Z_FUNC,
	VtblCall__IJ_3F_FUNC,
	VtblCall__IJ_3I_FUNC,
	VtblCall__IJ_3I_3I_FUNC,
	VtblCall__IJ_3I_3I_3I_3I_FUNC,
	VtblCall__IJ_3I_3J_FUNC,
	VtblCall__IJ_3I_3J_3J_FUNC,
	VtblCall__IJ_3J_FUNC,
	VtblCall__IJ_3J_3J_3J_FUNC,
	VtblCall__IJ_3S_FUNC,
	VtblCall__IJ_3Z_FUNC,
	memmove__JLorg_eclipse_swt_internal_mozilla_nsID_2I_FUNC,
	memmove__J_3BI_FUNC,
	memmove__J_3CI_FUNC,
	memmove__J_3II_FUNC,
	memmove__J_3JI_FUNC,
	memmove__Lorg_eclipse_swt_internal_mozilla_nsID_2JI_FUNC,
	memmove___3BJI_FUNC,
	memmove___3B_3CI_FUNC,
	memmove___3CJI_FUNC,
	memmove___3IJI_FUNC,
	memmove___3JJI_FUNC,
	nsEmbedCString_1Length_FUNC,
	nsEmbedCString_1delete_FUNC,
	nsEmbedCString_1get_FUNC,
	nsEmbedCString_1new___FUNC,
	nsEmbedCString_1new___3BI_FUNC,
	nsEmbedString_1Length_FUNC,
	nsEmbedString_1delete_FUNC,
	nsEmbedString_1get_FUNC,
	nsEmbedString_1new___FUNC,
	nsEmbedString_1new___3C_FUNC,
	nsID_1Equals_FUNC,
	nsID_1Parse_FUNC,
	nsID_1delete_FUNC,
	nsID_1new_FUNC,
	strlen_FUNC,
	strlen_1PRUnichar_FUNC,
} XPCOM_FUNCS;
